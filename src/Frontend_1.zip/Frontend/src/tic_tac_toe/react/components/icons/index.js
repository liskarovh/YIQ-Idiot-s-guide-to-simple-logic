export { default as BestMoveIcon } from './bestMoveIcon.jsx';
export { default as RestartIcon } from './restartIcon.jsx';
export { default as PauseIcon } from './pauseIcon.jsx';
export { default as PowerIcon } from './powerIcon.jsx';
export { default as InfoIcon } from './infoIcon.jsx';

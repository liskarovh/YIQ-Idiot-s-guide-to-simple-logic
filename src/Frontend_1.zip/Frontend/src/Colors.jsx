const colors = {
    text_header: '#FFFFFF',
    text: '#CBD5E1',
    text_faded: '#64748B',
    primary: '#020617',
    secondary: '#0F172A',
    win: '#2DC12D',
    lose: '#FF2121'
}

export default colors;
import React, { memo } from 'react';
import MarkX from './marks/markX.jsx';
import MarkO from './marks/markO.jsx';

const GRID_COLOR = 'rgba(203, 213, 225, 0.85)'; // #CBD5E1

/**
 * Props:
 *  - board: string[][]  // '.', 'X', 'O'
 *  - size: number
 *  - disabled?: boolean
 *  - pendingMove?: { row:number, col:number, mark?:'X'|'O' }
 *  - winnerLine?: Array<[number, number]>
 *  - onCell?: (r:number, c:number) => void
 */
function Board({
  board,
  size,
  disabled = false,
  pendingMove = null,
  winnerLine = null,
  onCell,
}) {
  const s = Number(size) || (board?.length ?? 3);

  const isInWinner = (r, c) =>
    Array.isArray(winnerLine) &&
    winnerLine.some(([rr, cc]) => rr === r && cc === c);

  const renderMark = (val) => {
    if (val === 'X') return <MarkX style={{ width: '72%', height: '72%' }} />;
    if (val === 'O') return <MarkO style={{ width: '72%', height: '72%' }} />;
    return null;
  };

  const canClick = (r, c) =>
    !disabled && typeof onCell === 'function' && board?.[r]?.[c] === '.';

  return (
    <div
      role="grid"
      aria-label={`Tic-Tac-Toe board ${s} by ${s}`}
      style={{
        position: 'relative',
        width: '100%',
        aspectRatio: '1 / 1',
        display: 'grid',
        gridTemplateColumns: `repeat(${s}, 1fr)`,
        gridTemplateRows: `repeat(${s}, 1fr)`,
        userSelect: 'none',
        border: `1px solid ${GRID_COLOR}`, // vnější border
        borderRadius: 6,
        overflow: 'hidden',                // nic nepřetéká
        background: 'transparent',
        pointerEvents: 'auto',
        zIndex: 3,
      }}
    >
      {/* --- GRID OVERLAY (místo borderů na buňkách) --- */}
      <div
        aria-hidden="true"
        style={{
          position: 'absolute',
          inset: 0,
          backgroundImage: `
            linear-gradient(to right, ${GRID_COLOR} 1px, transparent 1px),
            linear-gradient(to bottom, ${GRID_COLOR} 1px, transparent 1px)
          `,
          backgroundSize: `calc(100% / ${s}) 100%, 100% calc(100% / ${s})`,
          backgroundRepeat: 'repeat',
          backgroundPosition: '0 0, 0 0',
          pointerEvents: 'none',
          zIndex: 1,
        }}
      />

      {Array.from({ length: s }).map((_, r) =>
        Array.from({ length: s }).map((__, c) => {
          const val = board?.[r]?.[c] ?? '.';
          const isGhost =
            pendingMove &&
            pendingMove.row === r &&
            pendingMove.col === c &&
            val === '.';

          return (
            <div
              key={`${r}-${c}`}
              role="gridcell"
              aria-label={`cell ${r + 1},${c + 1}${val !== '.' ? ` ${val}` : ''}`}
              onClick={() => (canClick(r, c) ? onCell(r, c) : null)}
              style={{
                width: '100%',
                height: '100%',
                display: 'grid',
                placeItems: 'center',
                // (žádné vnitřní bordery — mřížku dělá overlay)
                pointerEvents: disabled ? 'none' : 'auto',
                cursor: canClick(r, c) ? 'pointer' : 'default',
                // highlight výherní buňky
                background: isInWinner(r, c)
                  ? 'rgba(255,255,255,0.06)'
                  : 'transparent',
                position: 'relative',
                zIndex: 2, // nad overlayem mřížky
              }}
            >
              {renderMark(val)}

              {isGhost && (
                <div
                  aria-hidden="true"
                  style={{
                    position: 'absolute',
                    inset: 0,
                    display: 'grid',
                    placeItems: 'center',
                    opacity: 0.35,
                    pointerEvents: 'none',
                  }}
                >
                  {pendingMove.mark === 'O' ? (
                    <MarkO style={{ width: '72%', height: '72%' }} />
                  ) : (
                    <MarkX style={{ width: '72%', height: '72%' }} />
                  )}
                </div>
              )}
            </div>
          );
        })
      )}
    </div>
  );
}

export default memo(Board);

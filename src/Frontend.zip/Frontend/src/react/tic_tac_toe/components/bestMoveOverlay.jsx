// src/Frontend/src/react/tic_tac_toe/components/bestMoveOverlay.jsx
import React, { useLayoutEffect, useState } from "react";
import { createPortal } from "react-dom";

export default function BestMoveOverlay({
  anchorRef,       // <- posílej statsRef (obal Game info karty)
  open,
  onClose,
  move,
  explain,
  loading,
  radius = 24,     // vizuálně sedí na Box
  pad = 12         // vnitřní odsazení pro „Best move“ box
}) {
  const [rect, setRect] = useState(null);

  useLayoutEffect(() => {
    if (!open) return;
    const el = anchorRef?.current;
    if (!el) return;

    const update = () => {
      const r = el.getBoundingClientRect();
      setRect({
        top: Math.round(r.top),
        left: Math.round(r.left),
        width: Math.round(r.width),
        height: Math.round(r.height),
      });
    };

    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    window.addEventListener("resize", update);
    window.addEventListener("scroll", update, { passive: true });
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", update);
      window.removeEventListener("scroll", update);
    };
  }, [open, anchorRef]);

  if (!open || !rect) return null;

  return createPortal(
    <div
      aria-hidden="true"
      onClick={onClose}
      style={{
        position: "fixed",
        top: rect.top,
        left: rect.left,
        width: rect.width,
        height: rect.height,
        zIndex: 2000,
        borderRadius: radius,
        // plachta přes CELÝ Game info panel
        background: "rgba(2, 6, 23, 0.55)",
        backdropFilter: "blur(2px)",
        boxShadow: "0 12px 30px rgba(0,0,0,0.35), -2px 4px 4px rgba(255,255,255,0.08)",
      }}
    >
      {/* vlastní box s obsahem overlaye */}
      <div
        role="dialog"
        aria-label="Best move"
        onClick={(e) => e.stopPropagation()} // klik dovnitř nezavírá
        style={{
          position: "absolute",
          top: pad,
          left: pad,
          right: pad,
          maxHeight: `calc(100% - ${pad * 2}px)`,
          overflow: "auto",
          borderRadius: radius,
          background: "#0F172A",
          color: "#CBD5E1",
          border: "2px solid #0F172A",
          padding: 16,
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <h3 style={{ margin: 0, fontWeight: 700 }}>Best move</h3>
          <button
            onClick={onClose}
            aria-label="Close"
            style={{
              marginLeft: "auto",
              background: "transparent",
              border: 0,
              color: "#CBD5E1",
              fontSize: 22,
              cursor: "pointer",
              lineHeight: 1,
            }}
          >
            ×
          </button>
        </div>

        {Array.isArray(move) && (
          <div style={{ opacity: 0.8, marginTop: 6 }}>
            Row {move[0] + 1}, Col {move[1] + 1}
          </div>
        )}
        <p style={{ margin: 0, whiteSpace: "pre-wrap" }}>
          {loading ? "Calculating…" : (explain || "—")}
        </p>
      </div>
    </div>,
    document.body
  );
}

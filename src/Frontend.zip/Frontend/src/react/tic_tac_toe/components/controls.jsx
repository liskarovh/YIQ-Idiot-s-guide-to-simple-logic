// src/Frontend/src/react/tic_tac_toe/components/controls.jsx
import React from 'react';
import colors from '../../../Colors';
import SettingsRow from '../../../components/SettingsRow';
import ButtonSelect from '../../../components/ButtonSelect';
import IconTextButton from '../../../components/IconTextButton';

/**
 * @param {{
 *  busy?: boolean,
 *  difficulty: 'easy'|'medium'|'hard',
 *  mode: 'pvp'|'pve',
 *  startMark: 'X'|'O'|'Random',
 *  onNew: () => void,
 *  onRestart: () => void,
 *  onBestMove: () => void,
 *  onChangeDifficulty: (d:'easy'|'medium'|'hard') => void,
 *  onChangeMode: (m:'pvp'|'pve') => void,
 *  onChangeStartMark: (s:'X'|'O'|'Random') => void
 * }} props
 */
export default function Controls({
  busy,
  difficulty, mode, startMark,
  onNew, onRestart, onBestMove,
  onChangeDifficulty, onChangeMode, onChangeStartMark
}) {
  const wrap = {
    display: 'grid',
    gap: '0.75rem',
    color: colors.text,
  };

  const twoCols = {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '0.5rem',
  };

  return (
    <div style={wrap}>
      {/* Akce */}
      <div style={twoCols}>
        <IconTextButton text="New" onClick={onNew} disabled={busy} />
        <IconTextButton text="Restart" onClick={onRestart} disabled={busy} />
      </div>

      <IconTextButton
        text="Best move"
        onClick={onBestMove}
        disabled={busy}
      />

      {/* Nastavení */}
      <SettingsRow label="Difficulty">
        <ButtonSelect
          options={['Easy','Medium','Hard']}
          selected={difficulty ? (difficulty[0].toUpperCase() + difficulty.slice(1)) : 'Easy'}
          onChange={(val) => onChangeDifficulty(val.toLowerCase())}
        />
      </SettingsRow>

      <SettingsRow label="Mode">
        <ButtonSelect
          options={['PvP','PvE']}
          selected={mode?.toUpperCase() === 'PVE' ? 'PvE' : 'PvP'}
          onChange={(val) => onChangeMode(val.toLowerCase())}
        />
      </SettingsRow>

      <SettingsRow label="Start">
        <ButtonSelect
          options={['X','O','Random']}
          selected={startMark ?? 'X'}
          onChange={onChangeStartMark}
        />
      </SettingsRow>
    </div>
  );
}

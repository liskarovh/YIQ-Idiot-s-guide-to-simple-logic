// src/Frontend/src/react/tic_tac_toe/components/anchorOverlay.jsx
import React, { useLayoutEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import colors from '../../../Colors';

export default function AnchorOverlay({
  anchorRef,
  open,
  onClose,
  pad = 16,          // vnitřní odsazení od okraje Game info
  children,
}) {
  const [pos, setPos] = useState(null);

  useLayoutEffect(() => {
    if (!open) return;
    const anchor = anchorRef?.current;
    if (!anchor) { setPos(null); return; }

    const calc = () => {
      const r = anchor.getBoundingClientRect();
      const w = Math.max(0, r.width  - 2 * pad);
      const h = Math.max(0, r.height - 2 * pad);
      setPos({
        left: Math.round(r.left + pad),
        top:  Math.round(r.top  + pad),
        width:  Math.round(w),
        height: Math.round(h),
      });
    };

    calc();
    const ro = new ResizeObserver(calc);
    ro.observe(anchor);
    window.addEventListener('resize', calc);
    window.addEventListener('scroll', calc, true);
    return () => {
      ro.disconnect();
      window.removeEventListener('resize', calc);
      window.removeEventListener('scroll', calc, true);
    };
  }, [open, anchorRef, pad]);

  if (!open || !pos) return null;

  return createPortal(
    <>
      {/* click-away bez ztmavení, mimo Game info nic nepřekrývá */}
      <div
        onClick={onClose}
        style={{ position: 'fixed', inset: 0, background: 'transparent', zIndex: 2000 }}
        aria-hidden="true"
      />
      <div
        style={{
          position: 'fixed',
          left: pos.left,
          top:  pos.top,
          width: pos.width,
          maxWidth: pos.width,
          maxHeight: pos.height,
          overflow: 'auto',
          borderRadius: 16,
          background: colors.secondary,
          color: colors.text,
          boxShadow: '0 10px 30px rgba(0,0,0,.35)',
          zIndex: 2001,
          pointerEvents: 'auto',
        }}
        role="dialog"
        aria-modal="true"
      >
        {children}
      </div>
    </>,
    document.body
  );
}

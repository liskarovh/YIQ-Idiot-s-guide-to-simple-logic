import { useEffect, useRef, useState } from 'react';

/**
 * Turn timer: čistý, znovupoužitelný.
 * @param {number} initialSeconds - kolik sekund má tah
 * @param {boolean} running       - běží/neběží
 * @param {any} resetKey          - když se změní, timer se resetne (např. změna hráče)
 */
export function useTurnCountdown(initialSeconds, running, resetKey) {
  const [left, setLeft] = useState(() => Math.max(0, Number(initialSeconds) || 0));
  const startedAtRef = useRef(null);
  const rafRef = useRef(0);

  // reset při změně limitu nebo resetKey
  useEffect(() => {
    setLeft(Math.max(0, Number(initialSeconds) || 0));
    startedAtRef.current = running ? performance.now() : null;
  }, [initialSeconds, resetKey]); // eslint-disable-line react-hooks/exhaustive-deps

  // běh
  useEffect(() => {
    const tick = (now) => {
      if (!running) return;
      if (startedAtRef.current == null) startedAtRef.current = now;
      const elapsed = (now - startedAtRef.current) / 1000;
      const next = Math.max(0, (Number(initialSeconds) || 0) - elapsed);
      setLeft(next);
      if (next > 0) rafRef.current = requestAnimationFrame(tick);
    };
    if (running) rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [running, initialSeconds]);

  return {
    secondsLeft: Math.ceil(left),
    progress: (Number(initialSeconds) || 0) > 0 ? Math.min(1, Math.max(0, left / Number(initialSeconds))) : 0,
  };
}

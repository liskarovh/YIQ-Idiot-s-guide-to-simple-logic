import { useEffect, useState } from 'react';

export function useMediaQuery(query) {
  const [matches, setMatches] = useState(() =>
    typeof window !== 'undefined' ? window.matchMedia(query).matches : false
  );
  useEffect(() => {
    const m = window.matchMedia(query);
    const on = () => setMatches(m.matches);
    m.addEventListener?.('change', on) || m.addListener?.(on);
    on();
    return () => m.removeEventListener?.('change', on) || m.removeListener?.(on);
  }, [query]);
  return matches;
}

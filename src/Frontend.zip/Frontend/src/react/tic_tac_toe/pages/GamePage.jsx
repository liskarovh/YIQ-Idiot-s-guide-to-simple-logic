// src/Frontend/src/react/tic_tac_toe/pages/GamePage.jsx
import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import Header from '../../../components/Header';

import Toolbar from '../components/toolbar.jsx';
import Board from '../components/board.jsx';
import BestMoveHint from '../components/bestMoveHint.jsx';
import BestMoveOverlay from '../components/bestMoveOverlay.jsx';
import UnderHeader from '../components/underHeader.jsx';
import GameInfoPanel from '../components/gameInfoPanel.jsx';
import { useGame } from '../hooks/useGame.js';
import { ttt } from '../features/ttt.client.js'; // ← fallback přímo na BE /best-move

export default function GamePage() {
  const navigate = useNavigate();
  const {
    game, loading, error, pendingMove, bestMove,
    restart, play, mode, players,
  } = useGame();

  const [paused, setPaused] = useState(false);

  // ====== Derivace čistě z DTO (žádné FE defaulty) ======
  const size   = Number.isFinite(Number(game?.size)) ? Number(game.size) : null;
  const kToWin = Number(game?.k_to_win ?? game?.goal ?? game?.kToWin ?? 0) || null;
  const difficulty =
    game?.difficulty ??
    game?.settings?.difficulty ??
    game?.ai?.difficulty ??
    null;

  const board = Array.isArray(game?.board) ? game.board : null;

  // Breakpoint – stacked když šířka < 980 px
  const [narrow, setNarrow] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia('(max-width: 980px)');
    const onChange = () => setNarrow(mq.matches);
    onChange();
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  // ===== Timer =====
  const boardSig = useMemo(() => (board ? board.flat().join('') : ''), [board]);

  function useTurnCountdown({ resetKey, initialSeconds, running }) {
    const [left, setLeft] = useState(initialSeconds);
    const deadlineRef = useRef(null);
    const leftRef = useRef(initialSeconds);
    const idRef = useRef(null);

    useEffect(() => {
      leftRef.current = initialSeconds;
      setLeft(initialSeconds);
      if (idRef.current) { clearInterval(idRef.current); idRef.current = null; }
      if (running) {
        deadlineRef.current = Date.now() + initialSeconds * 1000;
        const tick = () => {
          const ms = Math.max(0, (deadlineRef.current ?? 0) - Date.now());
          const sec = Math.ceil(ms / 1000);
          leftRef.current = sec;
          setLeft(sec);
        };
        tick();
        idRef.current = setInterval(tick, 250);
      }
      return () => { if (idRef.current) clearInterval(idRef.current); };
    }, [resetKey, initialSeconds, running]);

    useEffect(() => {
      if (running) {
        const resumeSec = Math.max(0, Number(leftRef.current) || initialSeconds);
        deadlineRef.current = Date.now() + resumeSec * 1000;
        if (idRef.current) clearInterval(idRef.current);
        const tick = () => {
          const ms = Math.max(0, (deadlineRef.current ?? 0) - Date.now());
          const sec = Math.ceil(ms / 1000);
          leftRef.current = sec;
          setLeft(sec);
        };
        tick();
        idRef.current = setInterval(tick, 250);
      } else if (idRef.current) {
        clearInterval(idRef.current); idRef.current = null;
      }
    }, [running, initialSeconds]);

    const mm = String(Math.floor(left / 60)).padStart(2, '0');
    const ss = String(left % 60).padStart(2, '0');
    return `${mm}:${ss}`;
  }

  const configuredSec = (() => {
    const fromGame = Number(game?.turnTimerSec ?? 0);
    return Number.isFinite(fromGame) && fromGame > 0 ? fromGame : 0;
  })();

  const timeRemaining = useTurnCountdown({
    resetKey: boardSig,
    initialSeconds: configuredSec,
    running: !!game && !paused && configuredSec > 0,
  });
  const timeDisplay = configuredSec > 0 ? timeRemaining : '—';

  // ===== Rozměry (robustní proti 0px při mountu) =====
  const headerRef = useRef(null);
  const shellRef   = useRef(null);
  const rightRef   = useRef(null);
  const toolbarRef = useRef(null);
  const statsRef   = useRef(null);
  const boardRef   = useRef(null);

  const HEADER_MIN_REM   = 7.0;
  const EXTRA_TOP_PX     = 8;
  const UNDER_PADDING_PX = 12;
  const SAFE_TOOLBAR_PX  = 160;

  const [headerPx, setHeaderPx] = useState(0);
  useLayoutEffect(() => {
    const recalcHeader = () => {
      const measured = headerRef.current?.getBoundingClientRect().height || 0;
      setHeaderPx(Math.round(measured));
    };
    recalcHeader();
    const ro = new ResizeObserver(recalcHeader);
    if (headerRef.current) ro.observe(headerRef.current);
    window.addEventListener('resize', recalcHeader);
    return () => { ro.disconnect(); window.removeEventListener('resize', recalcHeader); };
  }, []);

  const [boardPx, setBoardPx] = useState(0);
  const [panelMaxPx, setPanelMaxPx] = useState(0);
  const toolbarHRef = useRef(SAFE_TOOLBAR_PX);

  useLayoutEffect(() => {
    let raf1 = 0, raf2 = 0, rafSpin = 0;
    let roRight, roToolbar, roShell;

    const recompute = () => {
      const rightW     = rightRef.current?.getBoundingClientRect().width || 0;
      const viewportH  = window.innerHeight;

      const measuredTb  = toolbarRef.current?.getBoundingClientRect().height || 0;
      const tbH         = Math.max(SAFE_TOOLBAR_PX, measuredTb);
      toolbarHRef.current = tbH;

      const root = parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
      const baselinePx = HEADER_MIN_REM * root + EXTRA_TOP_PX;
      const headerTopPx = Math.max(headerPx, baselinePx);

      const containerH = Math.max(0, viewportH - headerTopPx - UNDER_PADDING_PX);
      setPanelMaxPx(Math.floor(containerH));

      const GAP = 12;
      const availableH = Math.max(0, containerH - tbH - GAP);

      const px = Math.max(0, Math.min(rightW, availableH));
      setBoardPx(prev => {
        if (px <= 0) return prev; // neprepisuj nenulovou hodnotu nulou
        return Math.floor(px);
      });
    };

    const spinUntilNonZero = (tries = 0) => {
      recompute();
      const w = rightRef.current?.getBoundingClientRect().width || 0;
      const ok = w > 0 && (toolbarHRef.current > 0);
      if (!ok && tries < 10) {
        rafSpin = requestAnimationFrame(() => spinUntilNonZero(tries + 1));
      }
    };

    recompute();
    raf1 = requestAnimationFrame(recompute);
    raf2 = requestAnimationFrame(() => setTimeout(recompute, 0));
    spinUntilNonZero();

    roRight   = new ResizeObserver(recompute);
    roToolbar = new ResizeObserver(recompute);
    roShell   = new ResizeObserver(recompute);
    if (rightRef.current)   roRight.observe(rightRef.current);
    if (toolbarRef.current) roToolbar.observe(toolbarRef.current);
    if (shellRef.current)   roShell.observe(shellRef.current);

    window.addEventListener('resize', recompute);

    if (document.fonts?.ready) {
      document.fonts.ready.then(() => { try { recompute(); } catch {} });
    }

    return () => {
      cancelAnimationFrame(raf1);
      cancelAnimationFrame(raf2);
      cancelAnimationFrame(rafSpin);
      roRight?.disconnect();
      roToolbar?.disconnect();
      roShell?.disconnect();
      window.removeEventListener('resize', recompute);
    };
  }, [narrow, headerPx, game?.id, game?.size]);

  // ===== Best move =====
  const [bestOpen, setBestOpen] = useState(false);
  const [bestState, setBestState] = useState({ loading: false, move: null, explain: '' });
  const [bestHintHidden, setBestHintHidden] = useState(false); // ← marker zmizí po zavření overlaye

  const onBestMoveClick = async () => {
    setBestHintHidden(false); // nový výpočet → marker může být vidět
    setBestOpen(true);
    setBestState({ loading: true, move: null, explain: '' });
    try {
      let r = null;

      // 1) pokus přes hook
      if (typeof bestMove === 'function') r = await bestMove();

      // 2) fallback – přímo BE volání, pokud hook nic nevrátil
      if (!r && game?.id) {
        try {
          r = await ttt.bestMove({ gameId: game.id, difficulty: difficulty || 'easy' });
        } catch (_) {}
      }

      const move = (r && Array.isArray(r.move)) ? r.move : null;
      const explain = r?.explain || r?.meta || '';
      setBestState({ loading: false, move, explain });
    } catch {
      setBestState({ loading: false, move: null, explain: 'Could not calculate best move.' });
    }
  };

  const handleCloseOverlay = () => {
    setBestOpen(false);
    setBestHintHidden(true); // ← po zavření overlaye marker zmizí
  };

  // === HIDE overlay + marker při PLAY (uživatelský klik) ===
  const onCell = (r, c) => {
    if (!paused && !loading && game) {
      setBestOpen(false);
      setBestHintHidden(true);
      play({ row: r, col: c });
    }
  };

  // === HIDE overlay + marker při jakékoli změně desky (např. AI tah) ===
  const prevSigRef = useRef(boardSig);
  useEffect(() => {
    if (!prevSigRef.current) { prevSigRef.current = boardSig; return; }
    if (boardSig && boardSig !== prevSigRef.current) {
      setBestOpen(false);
      setBestHintHidden(true);
    }
    prevSigRef.current = boardSig;
  }, [boardSig]);

  function TurnGlyph({ who = 'X' }) {
    if (String(who).toUpperCase() === 'O') {
      return (
        <svg width="clamp(22px, 2.2vw, 28px)" height="clamp(22px, 2.2vw, 28px)" viewBox="0 0 64 64" aria-label="O turn">
          <circle cx="32" cy="32" r="20" stroke="#38BDF8" strokeWidth="8" fill="none" />
        </svg>
      );
    }
    return (
        <svg width="clamp(22px, 2.2vw, 28px)" height="clamp(22px, 2.2vw, 28px)" viewBox="0 0 64 64" aria-label="X turn">
          <line x1="10" y1="10" x2="54" y2="54" stroke="#FF6B6B" strokeWidth="8" strokeLinecap="round" />
          <line x1="54" y1="10" x2="10" y2="54" stroke="#FF6B6B" strokeWidth="8" strokeLinecap="round" />
        </svg>
    );
  }

  // ===== Styly =====
  const page = {
    background: 'linear-gradient(180deg, #0F172A 0%, #020617 20%, #020617 60%, #0F172A 100%)',
    minHeight: '100svh',
    overflowX: 'hidden',
    overflowY: 'auto',
  };

  const shell = {
    boxSizing: 'border-box',
    width: 'min(1280px, 96vw)',
    margin: '0 auto',
    paddingInline: 'clamp(12px, 3vw, 24px)',
    display: 'grid',
    gridTemplateColumns: narrow ? '1fr' : 'minmax(280px, 36%) minmax(0, 1fr)',
    columnGap: narrow ? 0 : 'clamp(16px, 4vw, 72px)',
    rowGap: 'clamp(16px, 4vw, 32px)',
    alignItems: 'start',
    position: 'relative',
  };

  const rightColInner = { display: 'flex', flexDirection: 'column', alignItems: 'center', width: '100%', position: 'relative' };
  const boardWrap = {
    width:  boardPx > 0 ? `${boardPx}px` : 'min(60vw, 60vh)',
    height: boardPx > 0 ? `${boardPx}px` : 'min(60vw, 60vh)',
    position: 'relative',
    filter: 'drop-shadow(-2px 3px 4px #CBD5E1)',
    zIndex: 2
  };
  const toolbarOuter = {
    width: boardPx > 0 ? `${boardPx}px` : 'min(60vw, 60vh)',
    marginTop: 12,
    display: 'flex',
    justifyContent: 'center',
    position: 'relative',
    zIndex: 3
  };
  const toolbarInner = { width: '100%', position: 'relative' };
  const toolbarWrap = { position: 'relative', zIndex: 3,};

  const leftPausedOverlay  = paused ? { position: 'absolute', inset: 0, borderRadius: 'clamp(20px, 3vw, 40px)', background: 'rgba(2, 6, 23, 0.55)', backdropFilter: 'blur(1px)', zIndex: 2, pointerEvents: 'none' } : null;
  const rightPausedOverlay = paused ? { position: 'absolute', inset: 0, borderRadius: 0, background: 'rgba(2, 6, 23, 0.55)', backdropFilter: 'blur(1px)', zIndex: 1, pointerEvents: 'none' } : null;

  const bestMovePos = bestState.move ?? (Array.isArray(bestMove?.move) ? bestMove.move : null);
  const bestExplain = bestState.explain || bestMove?.explain || bestMove?.meta || '';

  // ====== LOADING SKELETON – dokud nemáme reálný board ze serveru ======
  const notReady = !game || !board || !size;

  if (notReady) {
    return (
      <div style={page}>
        <div ref={headerRef}>
          <Header showBack={false} onNavigate={(arg) => arg === 'back' ? navigate('/') : navigate(String(arg||'/'))} />
        </div>
        <UnderHeader headerRef={headerRef} center minRem={HEADER_MIN_REM} extraTopPx={EXTRA_TOP_PX} scrollY={'hidden'}>
          <div style={{ ...shell, placeItems: 'center', height: '60vh', color: '#CBD5E1' }}>
            Načítám hru…
          </div>
        </UnderHeader>
      </div>
    );
  }

  // ====== READY UI ======
  return (
    <div style={page}>
      <div ref={headerRef}>
        <Header
          showBack={false}
          onNavigate={(arg) => arg === 'back' ? navigate('/') : navigate(String(arg||'/'))}
        />
      </div>

      <UnderHeader
        headerRef={headerRef}
        center
        minRem={HEADER_MIN_REM}
        extraTopPx={EXTRA_TOP_PX}
        scrollY={narrow ? 'auto' : 'hidden'}
      >
        <div style={shell} ref={shellRef}>
          {/* levý panel – nikdy nepřeteče */}
          <div ref={statsRef} style={{ position: 'relative', maxHeight: `${panelMaxPx}px` }}>
            <GameInfoPanel
              players={players}
              mode={mode}
              kToWin={kToWin}
              size={size}
              timeDisplay={timeDisplay}
              maxHeightPx={panelMaxPx}
              TurnGlyph={TurnGlyph}
              player={game?.player || 'X'}
              difficulty={difficulty}
            />
            {leftPausedOverlay && <div style={leftPausedOverlay} aria-hidden="true" />}
          </div>

          {/* pravý sloupec – board + toolbar */}
          <div ref={rightRef} style={rightColInner}>
            {rightPausedOverlay && <div style={rightPausedOverlay} aria-hidden="true" />}

            <div ref={boardRef} style={boardWrap}>
              <Board
                board={board}
                size={size}
                disabled={paused || loading}
                pendingMove={pendingMove}
                winnerLine={null}
                onCell={onCell}
              />
              <BestMoveHint
                containerRef={boardRef}
                size={size}
                move={bestMovePos}
                show={!!bestMovePos && !bestHintHidden} // ← marker viditelný po výpočtu, zmizí po zavření overlaye / PLay / změně boardu
                cellInset={2}
              />
            </div>

            <div style={toolbarOuter}>
              <div ref={toolbarRef} style={toolbarInner}>
                <div style={toolbarWrap} data-toolbar>
                  <Toolbar
                    paused={paused}
                    onBestMove={onBestMoveClick}
                    onRestart={restart}
                    onPause={() => setPaused(p => !p)}
                    onPower={() => navigate('/')}
                    onStrategy={() => navigate('/about')}
                    bestMoveActive={bestOpen}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </UnderHeader>

      <BestMoveOverlay
        open={bestOpen}
        onClose={handleCloseOverlay}
        anchorRef={statsRef}
        move={bestMovePos}
        explain={bestExplain}
        loading={bestState.loading}
      />
    </div>
  );
}

// src/Frontend/src/react/tic_tac_toe/pages/StrategyPage.jsx
import React, { useLayoutEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import styles from '../../../Styles';
import colors from '../../../Colors';
import Header from '../../../components/Header';

export default function StrategyPage() {
  const navigate = useNavigate();
  const headerRef = useRef(null);
  const [topPad, setTopPad] = useState(120); // fallback, když ještě nemáme změřeno

  // Bezpečné měření výšky hlavičky (3 řádky? nevadí)
  useLayoutEffect(() => {
    const recalc = () => {
      const h = headerRef.current?.getBoundingClientRect().height || 0;
      // +8px vizuální mezera pod hlavičkou
      setTopPad(Math.max(96, Math.round(h) + 8));
    };
    recalc();
    const ro = new ResizeObserver(recalc);
    if (headerRef.current) ro.observe(headerRef.current);
    window.addEventListener('resize', recalc);
    return () => {
      ro.disconnect();
      window.removeEventListener('resize', recalc);
    };
  }, []);

  // ───── texty (3 sekce) ─────
  const lead =
    'A concise, practical guide to optimal tic-tac-toe: openings, forks and blocks, common pitfalls, and a simple decision algorithm for calculating the best move.';

  const sections = {
    overview: {
      leftTitle: 'Goal: force a win or a draw',
      leftIntro:
        'Tic-tac-toe is a solved game. With perfect play, the result is always a draw. Your aim is to capitalize on opponent mistakes while never leaving a winning opportunity open.',
      leftListTitle: 'The three principles to remember:',
      leftList: [
        'Control the center. It gives access to 4 lines at once.',
        'Create two threats at once (a fork). Opponent can block only one.',
        'Block open twos immediately. Never allow a free third mark.',
      ],
      rightTitle: 'Priority of moves',
      rightList: [
        'Win: if you have two in a row, complete it.',
        'Block: if the opponent has two in a row, block it.',
        'Fork: create a position with two simultaneous winning threats.',
        'Block fork: force the opponent to defend or take the center/corner accordingly.',
        'Center → Opposite corner → Empty corner → Empty side.',
      ],
    },
    forks: {
      leftTitle: 'Creating forks (two threats at once)',
      leftList: [
        'Corner + opposite corner with center occupied creates twin lines next move.',
        'Center + corner often yields a fork after placing on an empty corner.',
        'Use moves that participate in multiple lines; avoid sides unless they support a fork pattern.',
      ],
      rightTitle: 'Blocking forks',
      rightList: [
        'Win: if you have two in a row, complete it.',
        'Block: if the opponent has two in a row, block it.',
        'Fork: create a position with two simultaneous winning threats.',
        'Block fork: force the opponent to defend or take the center/corner accordingly.',
        'Center → Opposite corner → Empty corner → Empty side.',
      ],
    },
    algo: {
      leftTitle: 'Calculating the best move',
      leftList: [
        'Win: complete three/five in a row.',
        'Block: prevent opponent’s immediate win.',
        'Fork: create two threats at once.',
        'Block fork: play center, pressure corner, or force a single-reply.',
        'Play center when available.',
        'Play opposite corner if opponent has corner.',
        'Play any empty corner.',
        'Play an empty side as last resort.',
      ],
      rightTitle: 'Common pitfalls',
      rightList: [
        'Ignoring open twos (leaves forced loss next move).',
        'Side overuse in openings (weak tempo).',
        'Blocking one threat while allowing a fork.',
        'Chasing single lines instead of creating double threats.',
      ],
    },
  };

  const [tab, setTab] = useState('forks'); // výchozí dle tvého screenshotu
  const data = sections[tab];

  // ───── styly (jen inline, žádné další komponenty = nulové riziko runtime chyb) ─────
  const page = { ...styles.container, alignItems: 'stretch', padding: 0 };
  const container = {
    width: 'min(1200px, 92vw)',
    margin: '0 auto',
    padding: `0 0 28px`,
  };

  const title = {
    ...styles.mainTitleStyle,
    color: colors.text,
    textAlign: 'center',
    margin: `0 0 12px`,
  };
  const subtitle = {
    ...styles.subtitleStyle,
    textAlign: 'center',
    maxWidth: 980,
    margin: '0 auto 18px',
  };

  const pills = {
    display: 'flex',
    flexWrap: 'wrap',
    gap: 14,
    justifyContent: 'center',
    margin: '12px 0 18px',
  };
  const pillBase = {
    borderRadius: 9999,
    padding: '10px 18px',
    fontWeight: 700,
    border: `2px solid ${colors.surface}`,
    cursor: 'pointer',
  };
  const pillActive = {
    ...pillBase,
    background: colors.surface,
    color: colors.background,
  };
  const pillGhost = {
    ...pillBase,
    background: 'transparent',
    color: colors.text,
  };

  const grid = {
    display: 'grid',
    gridTemplateColumns: 'repeat(2, 1fr)',
    gap: 28,
  };
  const gridResponsive = {
    ...grid,
    gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
  };

  const card = {
    background: 'rgba(15,23,42,0.75)',
    borderRadius: 24,
    boxShadow: '0 2px 24px rgba(255,255,255,0.06) inset, 0 2px 6px rgba(0,0,0,0.35)',
    padding: '18px 22px',
    color: colors.text,
  };
  const h3 = { margin: '4px 0 12px', fontSize: 24 };

  return (
    <div style={page}>
      {/* Hlavička */}
      <div ref={headerRef}>
        <Header
          showBack
          backLabel="Back"
          onBack={() => navigate('/')}
          onNavigate={(p) => navigate(p)}
        />
      </div>

      {/* Obsah spolehlivě až pod hlavičkou */}
      <main style={{ ...container, marginTop: topPad }}>
        <h1 style={title}>Tic-tac-toe game strategy</h1>
        <p style={subtitle}>{lead}</p>

        {/* Pills */}
        <div style={pills}>
          <button
            type="button"
            style={tab === 'overview' ? pillActive : pillGhost}
            onClick={() => setTab('overview')}
          >
            Overview
          </button>
          <button
            type="button"
            style={tab === 'forks' ? pillActive : pillGhost}
            onClick={() => setTab('forks')}
          >
            Forks &amp; Blocks
          </button>
          <button
            type="button"
            style={tab === 'algo' ? pillActive : pillGhost}
            onClick={() => setTab('algo')}
          >
            Calculating the best move
          </button>
        </div>

        {/* Dvě karty – responzivně do sloupce */}
        <section style={gridResponsive}>
          <article style={card}>
            <h3 style={h3}>{data.leftTitle}</h3>
            {'leftIntro' in data && <p style={{ marginTop: 0 }}>{data.leftIntro}</p>}
            {'leftListTitle' in data && <strong>{data.leftListTitle}</strong>}
            <ol style={{ marginTop: 10 }}>
              {(data.leftList || []).map((t, i) => (
                <li key={i}>{t}</li>
              ))}
            </ol>
          </article>

          <article style={card}>
            <h3 style={h3}>{data.rightTitle}</h3>
            <ol style={{ marginTop: 10 }}>
              {data.rightList.map((t, i) => (
                <li key={i}>{t}</li>
              ))}
            </ol>
          </article>
        </section>

        <div style={{ textAlign: 'center', opacity: 0.6, marginTop: 24, fontSize: 14 }}>
          ©2025, All rights reserved
        </div>
      </main>
    </div>
  );
}

from typing import Literal

GameStatus = Literal['running', 'win', 'draw']
PlayerMark = Literal['X', 'O']
